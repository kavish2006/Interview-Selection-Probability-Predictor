import streamlit as st
import pickle
import numpy as np

# Load Model
model = pickle.load(open("model.pkl", "rb"))

# Page Config
st.set_page_config(
    page_title="Interview Selection Predictor",
    page_icon="🎯",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>

.stApp{
background: linear-gradient(
135deg,
#EEF2FF,
#FDF4FF,
#FFF1F2
);
}

/* Hide Streamlit menu */
#MainMenu, footer, header{
visibility:hidden;
}

/* Page spacing */
.block-container{
padding-top:1rem;
padding-left:5rem;
padding-right:5rem;
}

/* Main Title */
.main-title{
text-align:center;
font-size:78px;
font-weight:900;
line-height:1.1;

background:linear-gradient(
90deg,
#4338CA,
#7C3AED,
#EC4899
);

-webkit-background-clip:text;
-webkit-text-fill-color:transparent;

margin-bottom:5px;
}

/* Subtitle */
.sub-title{
text-align:center;
font-size:24px;
font-weight:500;
color:#475569;
margin-bottom:40px;
}

/* Section Headings */
.section{
font-size:30px;
font-weight:700;
color:#111827;
margin-top:15px;
margin-bottom:10px;
}

/* Labels */
label{
font-size:18px !important;
font-weight:600 !important;
color:#111827 !important;
}

/* Inputs */
input{
color:#111827 !important;
}

[data-testid="stNumberInput"] input{
background-color:#FFFFFF !important;
color:#111827 !important;
border-radius:10px;
}

/* Button */
.stButton > button{

width:100%;
height:75px;

border:none;
border-radius:18px;

font-size:28px;
font-weight:bold;

background:linear-gradient(
90deg,
#6366F1,
#EC4899
);

color:white;

box-shadow:0px 8px 20px rgba(99,102,241,0.25);

}

/* Footer */
.footer{
text-align:center;
font-size:22px;
font-weight:700;
margin-top:30px;

background:linear-gradient(
90deg,
#6366F1,
#EC4899
);

-webkit-background-clip:text;
-webkit-text-fill-color:transparent;
}

</style>
""", unsafe_allow_html=True)

# Heading
st.markdown("""
<p class="main-title">
🎯 Interview Selection Predictor
</p>
""", unsafe_allow_html=True)

st.markdown("""
<p class="sub-title">
Predict interview selection probability using Machine Learning
</p>
""", unsafe_allow_html=True)

# Inputs
col1, col2 = st.columns(2)

with col1:

    st.markdown(
    "<p class='section'>🎓 Academic Performance</p>",
    unsafe_allow_html=True
    )

    cgpa = st.slider(
        "CGPA",
        0.0,
        10.0,
        7.5
    )

    st.markdown(
    "<p class='section'>💬 Communication Skills</p>",
    unsafe_allow_html=True
    )

    communication = st.slider(
        "Communication Rating",
        1,
        10,
        7
    )

    st.markdown(
    "<p class='section'>📁 Projects</p>",
    unsafe_allow_html=True
    )

    projects = st.number_input(
        "Number of Projects",
        min_value=0,
        max_value=10,
        value=2
    )

with col2:

    st.markdown(
    "<p class='section'>💼 Internships</p>",
    unsafe_allow_html=True
    )

    internships = st.number_input(
        "Internships Completed",
        min_value=0,
        max_value=5,
        value=1
    )

    st.markdown(
    "<p class='section'>💻 Coding Skills</p>",
    unsafe_allow_html=True
    )

    coding = st.slider(
        "Coding Rating",
        1,
        10,
        7
    )

# Prediction Button
if st.button("🚀 Predict Result"):

    input_data = np.array([[
        cgpa,
        communication,
        projects,
        internships,
        coding
    ]])

    prediction = model.predict(input_data)
    probability = model.predict_proba(input_data)

    score = probability[0][1] * 100

    st.markdown("---")
    st.subheader("📊 Prediction Result")

    if prediction[0] == 1:

        st.success(
            f"✅ Candidate is likely to be selected.\n\nSelection Probability: {score:.2f}%"
        )

        st.balloons()

    else:

        st.error(
            f"❌ Candidate has lower chances of selection.\n\nSelection Probability: {score:.2f}%"
        )

    st.progress(int(score))

# Footer
st.markdown("""
<p class="footer">
✨ Made with ❤️ using Streamlit & Machine Learning ✨
</p>
""", unsafe_allow_html=True)