import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

# Reading dataset
data = pd.read_csv("interview_dataset.csv")

# Input features
x = data[['CGPA','Communication_Skills',
          'Projects','Internships',
          'Coding_Skills']]

# Output
y = data['Selected']

# Splitting dataset
x_train, x_test, y_train, y_test = train_test_split(
    x, y,
    test_size=0.2,
    random_state=42
)

# Model creation
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

# Training
model.fit(x_train,y_train)

# Saving model
pickle.dump(model,open("model.pkl","wb"))

print("Model saved successfully")